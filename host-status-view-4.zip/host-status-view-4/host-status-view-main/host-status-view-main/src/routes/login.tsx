import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { User, KeyRound, ArrowRight, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useStaff } from "@/components/AuthGuard";
import { supabase } from "@/lib/supabase";
import { EMPLOYEES } from "@/lib/employees";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Staff Login — Billing System For PlayHouse Cafe" },
      { name: "description", content: "Secure staff login." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const nav = useNavigate();
  const { staff, setStaff } = useStaff();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (staff) nav({ to: "/" }); }, [staff, nav]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      return toast.error("Enter both username and password");
    }

    setLoading(true);
    
    // Check local employees list (which is our source of truth requested by user)
    const validEmployee = EMPLOYEES.find(
      (emp) => emp.username.toLowerCase() === username.trim().toLowerCase() && emp.passwordId === password.trim()
    );

    if (!validEmployee) {
      setLoading(false);
      return toast.error("Invalid username or password");
    }

    // Save/sync this valid employee to the Supabase database
    try {
      await supabase.from("staff").upsert({
        id: validEmployee.passwordId, // using their ID as primary key
        name: validEmployee.username,
        role: validEmployee.role,
        pin: validEmployee.passwordId, // store password in pin
      }, { onConflict: "id" });
    } catch (err) {
      console.error("Failed to sync to db:", err);
      // Proceed anyway, DB sync is optional for logging in if it's in our valid list
    }

    setStaff({ name: validEmployee.username, mobile: "", loggedInAt: Date.now() });
    toast.success(`Welcome back, ${validEmployee.username}!`);
    nav({ to: "/" });
  };

  return (
    <div className="relative flex min-h-screen flex-col">
      <div className="absolute right-4 top-4"><ThemeToggle /></div>
      <main className="flex flex-1 items-center justify-center px-4 py-12">
        <div className="glass-strong w-full max-w-md rounded-3xl p-8 sm:p-10">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl text-primary-foreground" style={{ background: "var(--gradient-primary)" }}>
              <KeyRound className="h-6 w-6" />
            </div>
            <h1 className="font-display text-2xl font-bold">Billing System</h1>
            <p className="text-sm text-muted-foreground">For PlayHouse Cafe — Staff Login</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <Field icon={<User className="h-4 w-4" />} label="Username (First Name)">
              <input 
                value={username} 
                onChange={(e) => setUsername(e.target.value)} 
                placeholder="e.g. Praveenbalaji" 
                className="w-full bg-transparent outline-none" 
              />
            </Field>
            <Field icon={<KeyRound className="h-4 w-4" />} label="Password (ID)">
              <div className="flex w-full items-center">
                <input 
                  type={showPassword ? "text" : "password"}
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  placeholder="e.g. PHPS03" 
                  className="w-full bg-transparent outline-none" 
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-muted-foreground hover:text-foreground outline-none"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </Field>
            <PrimaryButton disabled={loading}>
              {loading ? "Verifying..." : "Login"} <ArrowRight className="h-4 w-4" />
            </PrimaryButton>
          </form>
        </div>
      </main>
    </div>
  );
}

function Field({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      <div className="glass flex items-center gap-2 rounded-xl px-3 py-2.5">
        <span className="text-muted-foreground">{icon}</span>
        {children}
      </div>
    </label>
  );
}

function PrimaryButton({ children, disabled }: { children: React.ReactNode; disabled?: boolean }) {
  return (
    <button type="submit" disabled={disabled} className="inline-flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold text-primary-foreground shadow-lg transition hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50" style={{ background: "var(--gradient-primary)" }}>
      {children}
    </button>
  );
}
